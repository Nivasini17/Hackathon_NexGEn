# smartobjectidentifier > 2024-07-20 1:18pm
https://universe.roboflow.com/saniya-sulthana/smartobjectidentifier

Provided by a Roboflow user
License: CC BY 4.0

